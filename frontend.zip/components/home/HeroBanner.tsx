const heroSections = [
  {
    title: "This Week's Savers",
    subtitle: "Stock up on family essentials with big discounts.",
    cta: "Shop Savers",
    color: "from-brand-50 to-brand-100"
  },
  {
    title: "Fresh Morning Basket",
    subtitle: "Milk, bread, eggs and vegetables in one delivery.",
    cta: "Schedule Slot",
    color: "from-sky-50 to-sky-100"
  }
];

export default function HeroBanner() {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <div className="lg:col-span-2 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-100 border shadow-sm p-6 flex flex-col justify-between">
        <div>
          <p className="text-xs font-semibold text-amber-700 uppercase tracking-wide">
            BuyNest Specials
          </p>
          <h2 className="mt-2 text-2xl font-bold text-gray-900">
            Daily Essentials at Smart Prices
          </h2>
          <p className="mt-2 text-sm text-gray-700 max-w-md">
            Groceries, personal care, home cleaning and more. Curated offers
            for your weekly basket.
          </p>
        </div>
        <button className="mt-4 inline-flex items-center px-4 py-2 rounded-md bg-brand-600 text-white text-sm font-medium hover:bg-brand-700">
          Shop Now
        </button>
      </div>

      <div className="space-y-4">
        {heroSections.map((s) => (
          <div
            key={s.title}
            className={`rounded-2xl bg-gradient-to-r ${s.color} border shadow-sm p-4 flex flex-col justify-between`}
          >
            <div>
              <h3 className="text-sm font-semibold text-gray-900">
                {s.title}
              </h3>
              <p className="text-xs text-gray-700 mt-1">
                {s.subtitle}
              </p>
            </div>
            <button className="mt-3 self-start text-xs font-medium text-brand-700 hover:text-brand-800">
              {s.cta} →
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
