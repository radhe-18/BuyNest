"use client";

import Link from "next/link";
import { useCart } from "@/store/cart";

export default function Header() {
  const totalQty = useCart((s) => s.totalQty());

  return (
    <header className="bg-white border-b sticky top-0 z-50">
      {/* ROW 1 */}
      <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between text-sm">
        {/* LEFT */}
        <Link href="/" className="text-2xl font-extrabold text-green-600">
          BuyNest
        </Link>

        {/* RIGHT */}
        <div className="flex items-center gap-6 font-medium">
          <button className="hover:text-green-600">Sign In</button>
          <button className="hover:text-green-600">My Orders</button>

          <Link
            href="/cart"
            className="relative px-4 py-1 rounded-full border border-green-600 text-green-700"
          >
            Cart
            {totalQty > 0 && (
              <span className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-green-600 text-white text-[10px] flex items-center justify-center">
                {totalQty}
              </span>
            )}
          </Link>
        </div>
      </div>

      {/* ROW 2 – CATEGORY STRIP */}
      <div className="bg-gray-50 border-t">
        <div className="max-w-7xl mx-auto px-4 h-10 flex items-center gap-5 overflow-x-auto text-xs font-medium text-gray-700">
          <Link href="/category/grocery-staples">Grocery & Staples</Link>
          <Link href="/category/fruits-vegetables">Fruits & Vegetables</Link>
          <Link href="/category/dairy-bakery">Dairy & Bakery</Link>
          <Link href="/category/beverages">Beverages</Link>
          <Link href="/category/snacks-branded-foods">Snacks & Branded Foods</Link>
          <Link href="/category/personal-care">Personal Care</Link>
          <Link href="/category/home-care">Home Care</Link>
          <Link href="/category/baby-kids">Baby & Kids</Link>
          <Link href="/category/household-kitchen">Household & Kitchen</Link>
        </div>
      </div>
    </header>
  );
}
