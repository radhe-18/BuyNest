import { products } from "@/data/products";
import ProductCard from "@/components/ProductCard";

type Props = {
  params: {
    slug: string;
  };
};

export default function CategoryPage({ params }: Props) {
  const categoryProducts = products.filter(
    (p) => p.category === params.slug
  );

  if (categoryProducts.length === 0) {
    return (
      <div className="p-8 text-center">
        <h2 className="text-xl font-semibold">No products found</h2>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6 capitalize">
        {params.slug.replace("-", " ")}
      </h1>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {categoryProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
