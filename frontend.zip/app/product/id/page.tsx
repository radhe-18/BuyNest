import { products } from "@/data/products";
import Image from "next/image";
import { notFound } from "next/navigation";

type Props = {
  params: {
    id: string;
  };
};

export default function ProductPage({ params }: Props) {
  const product = products.find(
    (p) => p.id === Number(params.id)
  );

  if (!product) return notFound();

  return (
    <div className="p-6 max-w-4xl mx-auto grid md:grid-cols-2 gap-6">
      <Image
        src={product.image}
        alt={product.name}
        width={350}
        height={350}
        className="object-contain"
      />

      <div>
        <h1 className="text-2xl font-bold">{product.name}</h1>
        <p className="text-gray-500 mt-2">{product.pack}</p>

        <p className="mt-4 text-xl font-bold text-green-600">
          ₹{product.price}
          <span className="line-through text-gray-400 ml-2 text-sm">
            ₹{product.mrp}
          </span>
        </p>

        <button className="mt-6 bg-green-600 text-white px-6 py-2 rounded">
          Add to Cart
        </button>
      </div>
    </div>
  );
}
