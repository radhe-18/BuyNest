import { products } from "@/data/products";
import Section from "@/components/home/Section";
import { HOME_CATEGORIES } from "@/data/categories";

export default function HomePage() {
  return (
    <div className="space-y-10">

      {/* PROMO STRIP */}
      <div className="bg-white border rounded-md py-2 px-3 text-[11px] sm:text-xs text-gray-700">
        Smart Savings · Everyday low prices · No minimum order for store pickup
      </div>

      {/* HERO */}
      <section className="bg-white border rounded-md p-5">
        <h1 className="text-2xl font-bold mb-2">
          BuyNest – Everyday Essentials at Best Prices
        </h1>
        <p className="text-sm text-gray-600 max-w-xl">
          Shop groceries, personal care and household needs – all in one place.
        </p>
      </section>

      {/* ✅ ALL SECTIONS – AUTO */}
      {HOME_CATEGORIES.map((cat) => {
        const categoryProducts = products.filter(
          (p) => p.category === cat.slug
        );

        if (categoryProducts.length === 0) return null;

        return (
          <Section
            key={cat.slug}
            title={cat.title}
            slug={cat.slug}
            products={categoryProducts.slice(0, 12)}
          />
        );
      })}

    </div>
  );
}
