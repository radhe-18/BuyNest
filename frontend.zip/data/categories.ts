export const HOME_CATEGORIES = [
  { title: "Grocery & Staples", slug: "grocery-staples" },
  { title: "Fruits & Vegetables", slug: "fruits-vegetables" },
  { title: "Dairy & Bakery", slug: "dairy-bakery" },
  { title: "Beverages", slug: "beverages" },
  { title: "Snacks & Branded Foods", slug: "snacks-branded-foods" },
  { title: "Personal Care", slug: "personal-care" },
  { title: "Home Care", slug: "home-care" },
  { title: "Baby & Kids", slug: "baby-kids" },
  { title: "Household & Kitchen", slug: "household-kitchen" },
];
